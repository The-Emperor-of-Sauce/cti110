#Gavin Bradshaw
#2/17/25
#P2LAB1
#get radius from user as a float
import math 
Radius=float(input("What is the radius of he circle?:"))
#calculate diameter

Diameter= 2* Radius

#calculate circumference
Circumference= 2 *math.pi * Radius

area=math.pi *Radius ** 2

print(f"The Diameter of the circle is {Diameter:.1f}")
print()
print(f"The Circumference of the circle is {Circumference:.2f}")
print()
print(f"The Area of the circle is {area:.2f}")
#Gavin Bradshaw
#3/10/25
#P3HW2
#Determine employee's regular pay, OT pay, and gross play

Name= input("Type Employee's name: ")
Hours= float(input("Type Employee's hours work: "))
Rate= float(input("Type Employee's pay rate: "))
if Hours > 40:
    Over_Time=(Hours-40)
    OT_Pay_Rate=(Rate * 1.5)
    OT_pay=(Over_Time * OT_Pay_Rate)
    reg_hours= 40
else:
    Over_Time=0.00
    OT_Pay_Rate= 0.00
    OT_pay= 0.00
    reg_hours = Hours

Reg_pay=(reg_hours * Rate)
Gross_pay=(OT_pay + Reg_pay)
print("---------------------------------------------")
print(f"Employee name: {Name}")
print()
print(f"{'Hours Worked':<20}{'Pay Rate':<20}{'OverTime':<20}{'OverTime Pay':<20}{'RegHour Pay':<20}{'Gross Pay':<20}")
print("----"* 30)
print(f"{Hours:<20}{Rate:<20}{Over_Time:<20.2f}{OT_pay:<20.2f}${Reg_pay:<20.2f}${Gross_pay:<20.2f}")




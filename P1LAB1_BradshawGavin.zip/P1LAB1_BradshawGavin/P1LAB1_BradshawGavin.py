#Gavin Bradshaw
#2/5/2025
#P1LAB1
#Using input and print funcitons 
first_name=input("Type your First Name:")
last_name=input("Type yuor Last Name:")


print("hello,", first_name, last_name + "!", "welcome to CTI_110")
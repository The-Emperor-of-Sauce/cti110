#Gavin Bradshaw
#P4LAB2
#3/19/2025
#making the times table
run_again = "yes"

while run_again != "no":
    user_num=int(input("Enter an integer: "))
    if user_num < 0:
        print("Can't do negative numbers dummy")
    else:
        for i in range(1,13):
            print(f"{user_num} * {i} = {user_num*i}")
    run_again= input("would you like to run again? 'yes'/'no': ")        

print("program has ended.....")
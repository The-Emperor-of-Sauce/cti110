# Gavin Bradshaw
# 2/19/2025
#P2LAB2
# knowledge of how to write code that uses a dictionary to store user input and displays output to the user

cars= {'Camaro':18.21, 'Prius':52.36, 'Model S':110, 'Silverado':26}

cars_keys= cars.keys()
print()
print(cars_keys)
print()

user_input= input("Enter your vehicle to see its mpg: ")
print()
print(f"the {user_input} gets {cars[user_input]}? ")
print()
miles= float(input(f"how many miles will you drive the {user_input}? "))
print()
num_gal= miles/cars[user_input]
print()
print(f"{num_gal:.2f} gallon(s) of gas are needed to drive the {user_input} {miles} miles.")


# Gavin Bradshaw 
#
#
#


print("This program calculates and display travel expenses")
print()
Budget=int(input("Enter budget:"))
print()
Travel_Destination=(input("Enter Travel Destination:"))
print()
Gas=float(int(input("how much do you think you will spend on gas?:")))
print()
Hotel=float(int(input("Approximately, how much will you for accomodation/hotel?:")))
print()
Food=float(int(input("Last, how much do you need for food?:")))
print()
print("------------Travel Expenses------------")
print(f"{'Location:':<20} {Travel_Destination}")
print(f"{'Initial Budget:': <20} {Budget:.2f}")
print(f"{'Fuel:':<20} {Gas:2f}")
print(f"{'Accomidation:':20} {Hotel:.2f}")
print(f"{'food:':<20} {Food:<2f}")
Total_Budget= Budget-Gas-Hotel-Food
print(f"{'Remaining Balance:':<20} {Total_Budget:<2f}")
print("---------------------------------------")
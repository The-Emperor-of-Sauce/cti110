#Gavin Bradshaw
#2/13/2025
#P1HW2
#Is how to insert vzlues and display them as well as solve a mathmadical equation.

print("This program calculates and display travel expenses")
print()
Budget=int(input("Enter budget:"))
print()
Travel_Destination=(input("Enter Travel Destination:"))
print()
Gas=int(input("how much do you think you will spend on gas?:"))
print()
Hotel=int(input("Approximately, how much will you for accomodation/hotel?:"))
print()
Food=int(input("Last, how much do you need for food?:"))
print()
print("------------Travel Expenses------------")
print("Location:",Travel_Destination)
print("Initial Budget:",Budget)
print()
print("Fuel:",Gas)
print("Accomidation:",Hotel)
print("food:",Food)
print()
Total_Budget= Budget-Gas-Hotel-Food
print("Remaining Balance:",Total_Budget)
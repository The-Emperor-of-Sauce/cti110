#Gavin Bradshaw
#4/7/2025
#P5HW_Game
#Making a games using functions

#example of choose-your-adventure gaem
import random
import time

classes = {
    "Warrior": {
        "items": ["Sword", "Shield", "Armor"],
        "health": 50,
        "armor": 50,
        "attack": (15, 25)
    },
    "Mage": {
        "items": ["Staff", "Spellbook", "Robe"],
        "health": 30,
        "armor": 10,
        "attack": (20, 30)
    },
    "Rogue": {
        "items": ["Dagger", "Lockpick", "Cloak"],
        "health": 40,
        "armor": 30,
        "attack": (10, 20)
    }
}

def calculate_damage_taken(damage, armor):
    return int(damage * (100 / (100 + armor)))

def loot_rewards(player, gold_range=(5, 20), possible_items=None):
    if possible_items is None:
        possible_items = ["Health Potion", "Enchanted Ring", "Gemstone", "Scroll of Firebolt"]

    gold_found = random.randint(*gold_range)
    item_found = random.choice(possible_items)

    player["gold"] += gold_found
    player["inventory"].append(item_found)

    print(f"\n🎉 Loot Found! 🎉")
    print(f"You found {gold_found} gold coins and a {item_found}!")
    print(f"Total Gold: {player['gold']}")
    print(f"Inventory: {player['inventory']}")

def create_character():
    name = input("Type your character's name: ")
    while not name:
        print("Name cannot be empty.")
        name = input("Type your character's name: ")

    print("Choose your class: ")
    for class_name in classes:
        print(f"{class_name}")
    while True:
        print("_" * 10)
        choice = input("Type the name of your chosen class: ")

        if choice in classes:
            selected = classes[choice]
            print("_" * 20)
            print(f"Welcome, {name} the {choice}!")
            print("Your starting items:")
            for item in selected["items"]:
                print(f"{item}")
            print(f"Health: {selected['health']}")
            print(f"Armor: {selected['armor']}")
            return {
                "name": name,
                "class": choice,
                "items": selected["items"],
                "armor_name": selected["items"][-1],
                "health": selected["health"],
                "max_health": selected["health"],  # Cap healing
                "armor": selected["armor"],
                "attack": selected["attack"],
                "inventory": [],
                "gold": 0
            }
        else:
            print("That's not a valid class. Please type it exactly as shown.")

def roll_dice(sides=20):
    input(f"Press enter to roll a d{sides}...")
    result = random.randint(1, sides)
    print(f"You rolled a {result}!")
    return result

def move_right():
    print(" You walk Further into the cave. The walls narrow, forcing you into single file as your torch casts long, twitching shadows. The damp stone underfoot gives way to patches of sticky mud and scattered bones — some animal… some not.")
    time.sleep(3.5)
    print("The air is heavier here, stale with the stench of rot and something more foul...")
    time.sleep(3.5)
    print("Unwashed bodies")
    time.sleep(1.5)
    print("old blood")
    time.sleep(1.5)
    print("smoke")
    time.sleep(1.5)
    print()
    print("A soft clatter of stone. A low snicker, sharp and wet. You freeze.")
    time.sleep(3.5)
    print("From the darkness ahead, a flicker of movement — glowing yellow eyes catch your torchlight for a split second. Then more. Two. Four. Six. They're watching.")
    time.sleep(3.5)
    print("A raspy voice chitters something in a harsh tongue, followed by another high-pitched giggle. You realize they were waiting for you.")
    time.sleep(3.5)
    print("Suddenly, a crude javelin clatters off the stone near your feet, followed by a shriek of laughter. Small, hunched shapes begin to emerge from the shadows, blades drawn, teeth bared.")
    time.sleep(3.5)
    print("GOBLINS!! they come low and fast, using the walls and rocks as cover. Youve got seconds to react.")
    time.sleep(3.5)
    print()
    # (rest of your move_right dialogue unchanged)
    time.sleep(3.5)
    print("ROLL Initiative.")
    fight_goblins(player)

def fight_goblins(player):
    player_health = player["health"]
    player_armor = player["armor"]
    player_attack = player["attack"]

    Goblins = [{"health": 10, "armor": 0, "attack": (5, 10)} for _ in range(3)]

    for i, Goblin in enumerate(Goblins):
        print(f"⚔️ Goblin {i+1} approaches!")
        player_roll = roll_dice(20)
        player_turn = player_roll >= 12

        if player_turn:
            print("You react quickly and act first!")
        else:
            print("The goblins lunge forward first!")

        while Goblin["health"] > 0 and player_health > 0:
            if player_turn:
                print("\nIt's your turn!")
                print("1. Attack")
                print("2. Use Health Potion")
                action = input("Choose your action (1 or 2): ")

                if action == "1":
                    damage = random.randint(*player_attack)
                    Goblin["health"] -= damage
                    print(f"You hit the goblin for {damage} damage! (Goblin HP: {max(Goblin['health'], 0)})")
                elif action == "2":
                    if "Health Potion" in player["inventory"]:
                        heal_amount = random.randint(10, 25)
                        player_health = min(player_health + heal_amount, player["max_health"])
                        player["inventory"].remove("Health Potion")
                        print(f"You drink a Health Potion and restore {heal_amount} HP! (Your HP: {player_health})")
                    else:
                        print("You have no Health Potions! You lose your turn fumbling through your bag.")
                else:
                    print("Invalid action. You hesitate and lose your turn.")
            else:
                damage = random.randint(*Goblin["attack"])
                actual_damage = calculate_damage_taken(damage, player_armor)
                player_health -= actual_damage
                print(f"Goblin hits you for {damage} damage! (You take {actual_damage}) (Your HP: {max(player_health, 0)})")

            if Goblin["health"] <= 0:
                print(f"Goblin {i+1} is defeated!")
                break
            if player_health <= 0:
                print("You collapse, the goblins shrieking in triumph...")
                print("Game Over.")
                return

            player_turn = not player_turn

    print("Victory! You defeated all the goblins.")
    player["health"] = player_health
    time.sleep(3.5)
    loot_rewards(player)

    print("\n1. Leave the cave and return to the surface — alive")
    print("2. Venture deeper into the darkness, where secrets still linger...")
    while True:
        choice = input("Do you [1] leave the cave or [2] explore deeper? ")
        if choice == "1":
            print("You survived the cave... but what else lies beneath?")
            break
        elif choice == "2":
            print()
            print("With grim determination, you push forward into the unknown.")
            time.sleep(3.5)
            print("The air thickens, the path narrows... something ancient stirs below.")
            time.sleep(3.5)
            print()
            print("Your footsteps echo louder as the narrow passage widens.")
            time.sleep(3.5)
            print("The air grows warmer, tinged with the acrid scent of smoke and something ancient.")
            time.sleep(3.5)
            print("You step into a colossal cavern — the ceiling lost in darkness above, walls glittering with embedded crystals.")
            time.sleep(3.5)
            print()
            print("Mountains of gold, silver, and glittering jewels spill across the floor like waves frozen in time.")
            time.sleep(3.5)
            print("Broken weapons, rusted armor, and forgotten crowns lie half-buried in the hoard, silent testaments to those who came before.")
            time.sleep(3.5)
            print()
            print("Atop the highest mound of treasure, a shape shifts — vast, coiled, breathing.")
            time.sleep(3.5)
            print("Two burning golden eyes snap open, locking onto you.")
            time.sleep(3.5)
            print()
            print("A deep, guttural rumble rolls through the chamber, like distant thunder.")
            time.sleep(3.5)
            print("Then a voice, low and ancient, fills the air:")
            time.sleep(3.5)
            print()
            print("  'Another thief come to take what is mine?'")
            time.sleep(3.5)
            print()
            print("The dragon rises, wings unfurling with the sound of cracking leather, its obsidian scales shimmering with heat.")
            time.sleep(3.5)
            print("The ground trembles as it steps forward, smoke curling from its nostrils.")
            time.sleep(3.5)
            print("You are in the presence of an ancient, sleeping god of fire... now fully awake.")
            print()
            time.sleep(3.5)
            print("A dragon awakens...")
            input("Press enter to fight the Dragon")
            fight_dragon(player)
            break
        else:
            print("Please type '1' to leave or '2' to explore deeper.")

def fight_dragon(player):
    player_health = player["health"]
    player_attack = player["attack"]

    dragon = {"health": 100, "attack": (15, 100)}
    print("🔥 The dragon rises, fury in its golden eyes! 🔥")

    player_turn = roll_dice(20) >= 12
    print("You act first!" if player_turn else "The dragon strikes first!")

    while dragon["health"] > 0 and player_health > 0:
        if player_turn:
            print("Your turn!")
            print("1. Attack")
            print("2. Use Health Potion")
            action = input("Choose your action (1 or 2): ")

            if action == "1":
                damage = random.randint(*player_attack)
                dragon["health"] -= damage
                print(f"You strike the dragon for {damage} damage! (Dragon HP: {max(dragon['health'], 0)})")
            elif action == "2":
                if "Health Potion" in player["inventory"]:
                    heal_amount = random.randint(10, 25)
                    player_health = min(player_health + heal_amount, player["max_health"])
                    player["inventory"].remove("Health Potion")
                    print(f"You restore {heal_amount} HP! (Your HP: {player_health})")
                else:
                    print("You have no potions and lose your turn.")
            else:
                print("Invalid choice. You lose your turn.")
        else:
            damage = random.randint(*dragon["attack"])
            actual_damage = calculate_damage_taken(damage, player["armor"])
            player_health -= actual_damage
            print(f"The dragon attacks for {damage}! You take {actual_damage}. (HP: {max(player_health, 0)})")

        if dragon["health"] <= 0:
            print("The dragon crashes to the ground with a thunderous roar!")
            loot_rewards(player, gold_range=(100, 300), possible_items=["Dragon Scale", "Ancient Crown", "Flameheart Amulet"])
            break

        if player_health <= 0:
            print("You drop to your knees, weapon slipping from numb fingers. The heat is unbearable — every breath like inhaling fire. Smoke curls around you as your vision begins to blur.")
            print()
            time.sleep(3.5)
            print("The dragon towers above, eyes glowing like molten gold. It leans in, exhaling a plume of smoke that curls around your broken form.")
            time.sleep(2)
            print()
            print("  'Pathetic'")
            time.sleep(1)
            print("it rumbles, voice like boulders grinding together.")
            print()
            time.sleep(2)
            print("  'Another fool chasing glory through ash and bone?'")
            time.sleep(1)
            print("It lets out a deep, thunderous chuckle that echoes through the cavern.")
            print()
            time.sleep(2)
            print("  'You are nothing but a spark — snuffed out before the flame ever caught.'")
            print()
            time.sleep(1)
            print("With a final snarl, the dragon turns away, its wings casting massive shadows across the treasure-strewn lair.")
            print("As your world fades to black, the last sound you hear is the slow, rhythmic beat of titanic wings… and the crackle of fire.")
            print("GAME OVER.")
            return

        player_turn = not player_turn

    player["health"] = player_health

def main():
    print("Welcome to Dungeons and Dragons!")
    time.sleep(1)
    print()
    print("You step toward the mouth of the cave, the light of day dimming behind you.The jagged stone entrance looms ahead like the gaping maw of some long-dead beast, teeth of rock hanging above and below." )
    print("As your boots cross the threshold, the temperature drops, and a damp, earthy scent clings to the air — moss, mold, and something... older.")
    time.sleep(3.5)
    print()
    print("With each step deeper into the gloom, your torch flickers against the stone walls, casting dancing shadows that play tricks on your eyes. Water drips somewhere in the distance — steady, rhythmic — echoing through the tunnel like the ticking of a clock.")
    time.sleep(3.5)
    print("Up ahead, the passage splits.")
    time.sleep(2)
    print()
    print("To the left, a low, jagged corridor curves out of sight, the air colder and thick with the faint scent of damp earth and mildew. You hear the occasional drip of water, steady and hollow — like something is waiting in the silence.")
    time.sleep(2)
    print()
    print("To the right, the tunnel appears smoother, as if worn by something — or someone — passing through regularly. There's a faint orange glow flickering against the stone, the source unseen, and the faintest trace of smoke or burnt wood in the air.")
    print()
    has_seen_dead_end = False

    while True:
        direction = input("Which direction? [left/right]: ") if not has_seen_dead_end else input("Do you go right? ")

        if direction == "left" and not has_seen_dead_end:
            print("The path narrows quickly, the walls closing in with jagged edges like crooked teeth. The air grows colder, damp with the smell of stale water and old moss. As you creep forward, the sound of dripping water echoes louder... then stops.")
            time.sleep(3.5)
            print("You round a bend — and find nothing.")
            time.sleep(3.5)
            print("A dead end. The tunnel abruptly ends at a wall of collapsed stone and rubble. There's no sign of life, only silence and a chill that lingers too long on your skin. For a moment, it feels like something was here — watching — but now it's gone.")
            time.sleep(3.5)
            print("You narrow your eyes at the rock wall ahead. Something about it seems… off. The way the torchlight hits it, the faint shimmer across the surface — it has to be an illusion.")
            time.sleep(3.5)
            print("You step forward, hand outstretched, half-expecting your fingers to pass through like mist.")
            print("Instead —")
            print()
            time.sleep(3.5)
            print("THUD.")
            time.sleep(2)
            print("Pain shoots through your hand as it smacks solid stone. You recoil, shaking it out with a hiss of breath.")
            print("No shimmer. No hidden door. Just cold, uncaring rock.")
            print()
            time.sleep(3.5)
            print("You glance around to make sure no one saw that.")
            print()
            time.sleep(3.5)
            print("The wall remains exactly what it is — a wall.")
            has_seen_dead_end = True
        elif direction == "right":
            move_right()
            break
        else:
            print("Not a valid direction. Try again.")

# Start the game
player = create_character()
main()
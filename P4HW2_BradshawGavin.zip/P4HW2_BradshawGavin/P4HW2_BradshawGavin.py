#Gavin Bradshaw
#P4HW2
#3/26/2025
#take P3HW2 and turn it into a loop
Total_Empolyees= 0
Total_OverTime = 0
Total_RegHrs = 0
Total_Gross = 0

Name= input("Type Employee's name or 'Done' to Terminate: ")

while Name.lower() != "done":
    Total_Empolyees += 1
    Hours= float(input("Type Employee's hours work: "))
    Rate= float(input("Type Employee's pay rate: "))
    if Hours > 40:
        Over_Time=(Hours-40)
        OT_Pay_Rate=(Rate * 1.5)
        OT_pay=(Over_Time * OT_Pay_Rate)
    else:
        Over_Time=0.00
        OT_Pay_Rate= 0.00
        OT_pay= 0.00
        
    reg_hours= 40
    Reg_pay=(reg_hours * Rate)
    Gross_pay=(OT_pay + Reg_pay)

    print("---------------------------------------------")
    print(f"Employee name: {Name}")
    print()
    print(f"{'Hours Worked':<20}{'Pay Rate':<20}{'OverTime':<20}{'OverTime Pay':<20}{'RegHour Pay':<20}{'Gross Pay':<20}")
    print("----"* 30)
    print(f"{Hours:<20}{Rate:<20}{Over_Time:<20}{OT_pay:<20}${Reg_pay:<20}${Gross_pay:<20}")
    print()
    Name= input("Type Employee's name or 'Done' to Terminate: ")
    
    Total_OverTime += OT_pay
    Total_RegHrs += Reg_pay
    Total_Gross += Gross_pay



print()
print(f"Total number of employees's entered: {Total_Empolyees}")
print(f"Total ammount paid for overtime: ${Total_OverTime}")
print(f"Total ammount paid for regular hours: ${Total_RegHrs}")
print(f"Total amount paid in Gross: ${Total_Gross}")


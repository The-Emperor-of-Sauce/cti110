#Gavin Bradshaw
#3/3/2025
#P3LAB
#Use if/else statements to determine coin combitnations

user_input_Original=float(input("Enter the Amount of money as a Float: $"))

user_input = int(user_input_Original * 100)

print(user_input)

#calculate number of whole dollars
number_dollars = user_input//100
print(f"Number of dollars: {number_dollars}")

#remove the dollars from the amount of money
user_input = user_input - (number_dollars * 100)
print(f"remaining {user_input}")

number_quarters= user_input//25
print(f"Number of quarters: {number_quarters}")
user_input = user_input - (number_quarters * 25)
print(f"remaining {user_input}")

number_dimes= user_input//10
print(f"Number of Dimes: {number_dimes}")
user_input = user_input - (number_dimes * 10)
print(f"remaining {user_input}")

number_nickles= user_input//5
print(f"Number of nickles:{number_nickles}")
user_input= user_input - (number_nickles * 5)
print(f"remaining {user_input}")

number_pennies= user_input
print(f"Number of Pennies:{number_pennies}")
print(f"remaining {user_input}")

#how display coins/dollars needed only if they are used
#Enusre all grammar is correct
print()
print()
print()

print(f"${user_input_Original:.2f}")
if number_dollars > 0:
    if number_dollars ==1:
        print(f"{number_dollars} Dollar")
    else:
        print(f"{number_dollars} Dollars")

if number_quarters > 0:
    if number_quarters ==1:
        print(f"{number_quarters} Quarter")
    else:
        print(f"{number_quarters} Quarters")

if number_dimes > 0:
    if number_dimes ==1:
        print(f"{number_dimes} Dime")
    else:
        print(f"{number_dimes} Dimes")

if number_dimes > 0:
    if number_dimes ==1:
        print(f"{number_dimes} Dime")
    else:
        print(f"{number_dimes} Dimes")

if number_nickles > 0:
    if number_nickles ==1:
        print(f"{number_nickles} Nickle")
    else:
        print(f"{number_nickles} Nickles")

if number_pennies > 0:
    if number_pennies ==1:
        print(f"{number_pennies} Penny")
    else:
        print(f"{number_pennies} Pennies")

#If no change is due, display "No Change"
if user_input_Original <=0.00:
    print(f"No change")
#Display Dollars
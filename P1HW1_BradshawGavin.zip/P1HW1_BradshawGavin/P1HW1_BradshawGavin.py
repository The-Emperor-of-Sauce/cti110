#Gavin Bradshaw
#2/12/2025
#P1HW1
#how to use exponentes on integer, as well as simple addition and subtraction

print("---Calculating Exponenets----")
integer_1=int(input("Enter an integer as the base value:"))
Exponent_1=int(input("Enter an integer as the exponent"))
#calculate for exponent
Total= integer_1 ** Exponent_1
print()
print()
print(integer_1,"raised to the power of",Exponent_1,"is",Total)
print()
print()
print("----Addition and Subtraction----")
print()
print()
Starting_Integer=int(input("Enter a Starting integer:"))
Integer_Add=int(input("Enter a integer to add:"))
Integer_Subtract=int(input("Enter a integer to subrtact:"))
Total_2= Starting_Integer + Integer_Add - Integer_Subtract
print()
print()
print(Starting_Integer,"+",Integer_Add,"-",Integer_Subtract,"is equal to",Total_2)

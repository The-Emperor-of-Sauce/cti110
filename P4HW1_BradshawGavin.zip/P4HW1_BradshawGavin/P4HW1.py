#Gavin Bradshaw
#P4HW1
#3/24/2025
#

#create empty list

#add grade to gades list 

#while grade <0 or Grade is >100 tell user grade is invalid

#find the lowest score min(Garde list) remove min from list

#calculate the average 
num_Scores=int(input("Enter score do you want te enter?: "))
Grade_list=[]

for Score in range(num_Scores):
    Grade=int(input(f"Enter score #{Score + 1}: "))
    while Grade <0 or Grade >100:
        print("HOW DID YOU GET THIS?!")
        print("SCORES SHOULD BE BETWEEN 0 AND 100")
        Grade=int(input(f"Enter score #{Score + 1} again: "))
    Grade_list.append(Grade)
    
print()    
Lowest_grade=min(Grade_list)
Grade_list.remove(Lowest_grade)
Total = sum(Grade_list)
avg = Total/len(Grade_list)


print("_"*40)
print(f"Lowest Grade :{Lowest_grade}")
print(f"Modified List: {Grade_list}")
print(f"Average: {avg}")
if avg >= 90:
 print("Your grade is: A")

elif avg >= 80:
  print('Your grade is: B')
 
elif avg >= 70:
   print("Your grade is: C")
 
elif avg >=60:
    print("Your grade is: D")

else:
    print('Your grade is: F') 

print("_"*40)